// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Test concurrency primitives: power series.

package main

import (
	"flag"
	"fmt"
	"os"
	"time"

	. "github.com/GoLangsam/ps"
)

var ( //flags
	n int
	x bool

	cn, cd int64
)

func init() {
	flag.IntVar(&n, "n", 0, "# of sample: 0 = all")
	flag.BoolVar(&x, "x", true, "use os.Exit(1) to see leaking goroutines, if any")
	flag.Int64Var(&cn, "cn", 1, "Coefficient: Numerator")
	flag.Int64Var(&cd, "cd", 1, "Coefficient: Denominator")
	flag.Parse()
}

// ===========================================================================
// special rational coefficients

var (
	aZero     Coefficient // 0
	aOne      Coefficient // 1
	aMinusOne Coefficient // -1
)

func init() {
	aZero = NewCoefficient(0, 1)      // 0
	aOne = NewCoefficient(1, 1)       // 1
	aMinusOne = NewCoefficient(-1, 1) // -1 - aMinusOne.Neg(aOne) raises `nil` exception ?!?
}

// ===========================================================================

func poly() PS {
	return Polynom(
		NewCoefficient(1, 1),
		NewCoefficient(1, 2),
		NewCoefficient(1, 3),
		NewCoefficient(1, 4),
		NewCoefficient(1, 5),
	)
}

func one() PS {
	return Polynom(
		NewCoefficient(1, 1),
	)
}

func lin() PS {
	return Polynom(
		NewCoefficient(1, 1),
		NewCoefficient(1, 1),
	)
}

func sqr() PS {
	return Polynom(
		NewCoefficient(1, 1),
		NewCoefficient(1, 1),
		NewCoefficient(1, 1),
	)
}

func sample(n int) {

	//	var c Coefficient
	const N = 10
	switch n {

	case 1:
		fmt.Print("#", n, " Poly: ")
		poly().Printn(10)

	case 2:
		fmt.Println("#", n, " 1*1: ")
		Mul(one(), one()).Printn(N)
	case 3:
		fmt.Println("#", n, " 1+x: ")
		Mul(one(), lin()).Printn(N)
	case 4:
		fmt.Println("#", n, " x+1: ")
		Mul(lin(), one()).Printn(N)
	case 5:
		fmt.Println("#", n, " (1+x)^2: ")
		Mul(lin(), lin()).Printn(N)
	case 6:
		fmt.Println("#", n, " 1*3: ")
		Mul(one(), sqr()).Printn(N)
	case 7:
		fmt.Println("#", n, " 3*1: ")
		Mul(sqr(), one()).Printn(N)
	case 8:
		fmt.Println("#", n, " 2*3: ")
		Mul(lin(), sqr()).Printn(N)
	case 9:
		fmt.Println("#", n, " 3*2: ")
		Mul(sqr(), lin()).Printn(N)
	case 10:
		fmt.Println("#", n, " 3*3: ")
		Mul(sqr(), sqr()).Printn(N)
	default:
		fmt.Println("No such sample #", n, " - max =", max)

	}

}

const max = 10 // # of samples

func main() {

	if n > 0 {
		sample(n)
	} else {
		for i := 1; i <= max; i++ {
			sample(i)
		}
	}

	if x {
		fmt.Println("about to leave ...")
		<-time.After(time.Millisecond * 100)
		os.Exit(1) // to see leaking goroutines, if any
	}

}
