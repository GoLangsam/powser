// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

// ===========================================================================
// Arithmetic on power series: each spawns a goroutine

// Conventions
// Upper-case for power series.
// Lower-case for coefficients.
// Input variables:  From U,V,...
// Output variables: Into ...,Y,Z

// add two power series.
func add(U, V PsFrom) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U, V PsFrom) {
		defer func() {
			U.Drop()
			V.Drop()
			Z.Close()
		}()

		for Z.Next() {
			u, okU, v, okV := U.GetWith(V)
			if !okU && !okV {
				return
			}
			Z.Send(aC().Add(u, v)) // `u + v`
		}
	}(Into, U, V)
	return Z
}

// Plus adds powerseries to `U`
// and returns the sum.
// Tail-recursion is used to achieve this.
func (U PsFrom) Plus(V ...PsFrom) PsFrom {
	switch len(V) {
	case 0:
		return U
	case 1:
		return add(U, V[0])
	default:
		return add(U, V[0]).Plus(V[1:]...)
	}
}

// minus subtracts `V` from `U`
// and returns `U + (-1)*V`
func (U PsFrom) minus(V PsFrom) PsFrom {
	return U.Plus(V.CMul(aMinusOne()))
}

// Less subtracts powerseries from `U`
// and returns the difference.
// Tail-recursion is used to achieve this.
func (U PsFrom) Less(V ...PsFrom) PsFrom {
	switch len(V) {
	case 0:
		return U
	case 1:
		return U.minus(V[0])
	default:
		return U.minus(V[0]).Less(V[1:]...)
	}
}

// CMul multiplies `U` by a constant `c`
// and returns `c*U`.
func (U PsFrom) CMul(c Coefficient) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom, c Coefficient) {
		for Z.SendCfnFrom(U, cMul(c)) { // `c * u`
		}
	}(Into, U, c)
	return Z
}

// MonMul multiplies `U` by the monomial "x^n"
// and returns `x^n * U`.
func (U PsFrom) MonMul(n int) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom, n int) {
		for ; n > 0; n-- {
			Z.Put(aZero())
		}
		Z.Append(U)
	}(Into, U, n)
	return Z
}

// XMul multiplies `U` by `x`
// (by the monomial "x^1")
// and returns `x * U`.
func (U PsFrom) XMul() PsFrom {
	return U.MonMul(1)
}

// Shift returns `c + x*U`
func (U PsFrom) Shift(c Coefficient) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom, c Coefficient) {
		Z.Put(c)
		Z.Append(U)
	}(Into, U, c)
	return Z
}

// mul multiplies. The algorithm is:
//	let U = `u + x*UU`
//	let V = `v + x*VV`
//	then UV = `u*v + x*(u*VV+v*UU) + x*x*UU*VV`
func mul(U, V PsFrom) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U, V PsFrom) {
		var u, v Coefficient
		var next, okU, okV bool

		if next = Z.Next(); next {
			u, okU, v, okV = U.GetWith(V)
		}

		if !next || !okU || !okV { // Z.Dropped or U or V.Closed
			U.Drop()
			V.Drop()
			Z.Close()
			return
		}

		Z.Send(aC().Mul(u, v))                 // `u*v`
		UU, VV := U.Split(), V.Split()         // `UU`, `VV`
		W := VV[0].CMul(u).Plus(UU[0].CMul(v)) // `u*VV + v*UU`
		if Z.SendCfnFrom(W, cSame()) {         // ` + x*(u*VV+v*UU)`
			Z.Append(W.Plus(mul(UU[1], VV[1]))) // `+ x*x*UU*VV` - recurse
		}
	}(Into, U, V)
	return Z
}

// Times multiplies powerseries to `U`
// and returns the total product.
// Tail-recursion is used to achieve this.
func (U PsFrom) Times(V ...PsFrom) PsFrom {
	switch len(V) {
	case 0:
		return U
	case 1:
		return mul(U, V[0])
	default:
		return mul(U, V[0]).Times(V[1:]...)
	}
}

// Deriv differentiates `U`
// and returns the derivative.
func (U PsFrom) Deriv() PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom) {
		if _, ok := Z.GetNextFrom(U); !ok {
			return
		}
		// constant term: drop
		// Thus: we must Z.Send() before another Z.Next(),
		// we may not use an Obtain-loop and we have to do the cleanup ourselfs.

		for i := 1; ; i++ {
			if u, ok := U.Get(); ok {
				Z.Send(cRatIby1(i)(u)) // `u * i`
				if !Z.Next() {
					break
				}
			} else {
				break
			}
		}
		Z.Close()
		U.Drop()
	}(Into, U)
	return Z
}

// Integrate, with const of integration.
func (U PsFrom) Integ(c Coefficient) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom, c Coefficient) {
		Z.Put(c)

		i := 1
		for Z.SendCfnFrom(U, cRat1byI(i)) { // `u * 1/i`
			i++
		}
	}(Into, U, c)
	return Z
}

// Recip rocal of a power series. The algorithm is:
//	let U = `u + x*UU`
//	let Z = `z + x*ZZ`
//	`(u+x*UU)*(z+x*ZZ) = 1`
//	`z = 1/u`
//	`u*ZZ + z*UU + x*UU*ZZ = 0`
//
//	ZZ = `1/u * -UU * (z + x*ZZ)`
//	ZZ = `1/u * (-z*UU + x*UU*ZZ)`
func (U PsFrom) Recip() PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom) {
		u, ok := Z.GetNextFrom(U)
		if !ok {
			return
		}
		Z.Send(aC().Inv(u)) // `1/u`
		mu := aC().Neg(u)   // `-z` minus z
		ZZ, Z1, Z2 := U.newPair()
		ZZ.Split(U.CMul(mu).Times(Z1.Shift(u)))
		Z.Append(Z2)
	}(Into, U)
	return Z
}

// Exp onential of a power series with constant term equal zero:
//	Z = exp(U)
//	DZ = Z*DU
//	integrate to get Z
// Note: The constant term is simply ignored as
// any nonzero constant term would imply nonrational coefficients.
func (U PsFrom) Exp() PsFrom {
	ZZ, Z1, Z2 := U.newPair()
	ZZ.Split(Z1.Times(U.Deriv()).Integ(aOne()))
	return Z2
}

// Subst itute V for x in U, where the constant term of V is zero:
//	let U = `u + x*UU`
//	let V = `v + x*VV`
//	then Subst(U,V) = `u + VV * Subst(U,VV)`
// Note: Any nonzero constant term of `V` is simply ignored.
func (U PsFrom) Subst(V PsFrom) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U, V PsFrom) {
		if !Z.SendCfnFrom(U, cSame()) {
			V.Drop()
			return
		}

		VV := V.Split()
		VV[0].Get() // Note: Any nonzero constant term of `V` is ignored.
		Z.Append(VV[0].Times(U.Subst(VV[1])))

	}(Into, U, V)
	return Z
}

// MonSubst Monomial Substition: `U(c*x^n)`
// Each Ui is multiplied by `c^i` and followed by n-1 zeros.
func (U PsFrom) MonSubst(c0 Coefficient, n int) PsFrom {
	Into, Z := U.new()
	go func(Z PsInto, U PsFrom, c0 Coefficient, n int) {
		c := aOne()
		for Z.SendCfnFrom(U, cMul(c)) { // `c * u`
			for i := 1; i < n; i++ {
				if !Z.Put(aZero()) { // n-1 zeros
					Z.Close()
					U.Drop()
					return
				}
			}
			c.Mul(c, c0) // `c = c * c0 = c^i`
		}
	}(Into, U, c0, n)
	return Z
}

// ===========================================================================
