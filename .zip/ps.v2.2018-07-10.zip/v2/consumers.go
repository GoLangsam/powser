// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

// ===========================================================================
// Consumers: Eval & Print

// Conventions
// Upper-case for power series.
// Lower-case for coefficients.
// Input variables: U,V,...
// Output variables: ...,Y,Z

// EvalAt evaluates a power series at `x=c`
// for up to `n` terms.
func (U PsFrom) EvalAt(c Coefficient, n int) Coefficient {
	u, ok := U.Get()
	switch {
	case ok && n == 1:
		return u
	case ok && n > 1:
		return aC().Add(u, aC().Mul(c, U.EvalAt(c, n-1))) // `u + c*U`
	default:
		U.Drop()
		return aZero()
	}
}

// EvalN evaluates a power series at `x=c`
// for up to `n` terms in floating point.
func (U PsFrom) EvalN(c Coefficient, n int) float64 {
	defer U.Drop()

	ci := float64(1)
	fc, _ := c.Float64()
	val := float64(0)

	var u Coefficient
	var fu float64
	var ok bool
	for i := 0; i < n; i++ {
		if u, ok = U.Get(); !ok {
			break
		}
		fu, _ = u.Float64()
		val += fu * ci // val += `u(i) * c^i`
		ci = fc * ci   // `c^(i+1) = c * c^i`
	}
	return val
}

// Printn prints up to n terms of a power series.
func (U PsFrom) Printn(n int) {
	defer U.Drop()
	defer print(("\n"))

	var u Coefficient
	var ok bool
	for ; n > 0; n-- {
		if u, ok = U.Get(); !ok {
			return
		}
		print(u.String())
		print(" ")
	}
}

// Printer returns a copy of `U`,
// and concurrently prints up to n terms of it.
// Useful to inspect formulas.
func (U PsFrom) Printer(n int) PsFrom {
	UU := U.Split()

	go func(U PsFrom, n int) {
		U.Printn(n)
	}(U, n)
	return UU[1]
}

// Print one billion terms. Use at Your own risk ;-)
func (U PsFrom) Print() {
	U.Printn(1000000000)
}

// ===========================================================================
