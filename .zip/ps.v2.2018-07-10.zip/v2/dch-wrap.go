// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

// ===========================================================================
// Wrappers for multi-argument methods
// use dch.MyDchInto() and dch.MyDchFrom() to obtain the anonymously embedded value
// and invoke its underlying method.

// Append all coefficients from `From` into `Into`.
func (Into PsInto) Append(From PsFrom) {
	Into.MyDchInto().Append(From.MyDchFrom())
}

// append all coefficients from `From` into `Into`.
// without cleanup of handshaking resources.
func (Into PsInto) append(From PsFrom) {
	Into.MyDchInto().AppendOnly(From.MyDchFrom())
}

// GetNextFrom `From` for `Into` and report success.
// Follow with `Into.Send( f(c) )`, iff ok.
func (Into PsInto) GetNextFrom(From PsFrom) (c Coefficient, ok bool) {
	return Into.MyDchInto().GetNextFrom(From.MyDchFrom())
}

// GetWith returns each first value received from the two given power series
// together with their respective ok boolean.
func (From PsFrom) GetWith(With PsFrom) (cU Coefficient, okU bool, cV Coefficient, okV bool) {
	cU, okU, cV, okV = From.MyDchFrom().GetWith(With.MyDchFrom())
	if !okU {
		cU = aZero()
	}
	if !okV {
		cV = aZero()
	}

	return
}

// Split returns a pair of power series identical to the given one.
func (From PsFrom) Split() [2]PsFrom {
	oneInto, oneFrom := New()
	twoInto, twoFrom := New()
	From.MyDchFrom().SplitUs(oneInto.MyDchInto(), twoInto.MyDchInto())
	return [2]PsFrom{oneFrom, twoFrom}
}

// ---------------------------------------------------------------------------

// ps is a two-sided power series - for internal use only
type ps struct {
	PsInto
	PsFrom
}

// pairPS represents a pair of power series.
type pairPS [2]ps

// newPair returns an empty pair of new power series.
func (From PsFrom) newPair() (pairPS, PsFrom, PsFrom) {
	oneInto, oneFrom := New()
	twoInto, twoFrom := New()
	onePair := ps{oneInto, oneFrom}
	twoPair := ps{twoInto, twoFrom}
	pair := [2]ps{onePair, twoPair}
	return pair, oneFrom, twoFrom
}

// Note: This construction may seem a little awkward.
// Just: Its a pretty way to build a pair of pairs.
// And: It enables subtle algorithmic code such as:
// 	ZZ, Z1, Z2 := U.newPair
// 	ZZ.Split(Z1 ...)
// 	Z.Append(Z2)
// Notice the self-referential use of Split!

// Split `From` into a given pair of power series.
func (UU pairPS) Split(From PsFrom) {
	From.MyDchFrom().SplitUs(UU[0].MyDchInto(), UU[1].MyDchInto())
}

// ===========================================================================
