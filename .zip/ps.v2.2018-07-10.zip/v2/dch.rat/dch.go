// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dch

import (
	// "math/big"
	"github.com/GoLangsam/ps/big"
)

// ===========================================================================
// Beg of demand channel object

// dch is a
// demand channel.
type dch struct {
	ch  chan *big.Rat
	req chan struct{}
}

// DchFrom is a lazy read-only channel: receive a next value upon request.
// Call `Drop()` when finished reading.
type DchFrom struct {
	ch  <-chan *big.Rat
	req chan<- struct{}
}

// DchInto is a lazy send-only channel: send a next value on demand only.
// Call `Close()` when finished sending.
type DchInto struct {
	ch  chan<- *big.Rat
	req <-chan struct{}
}

// New returns
// a (pointer to a) fresh
// unbuffered
// demand channel.
func New() (*DchInto, *DchFrom) {
	d := dch{
		ch:  make(chan *big.Rat),
		req: make(chan struct{}),
	}
	from := DchFrom{
		ch:  d.ch,
		req: d.req,
	}

	into := DchInto{
		ch:  d.ch,
		req: d.req,
	}

	return &into, &from
}

// ---------------------------------------------------------------------------

// Get is the comma-ok multi-valued form to receive from the channel and
// reports whether a received value was sent before the channel was closed.
//
// Get blocks until the request is accepted and value `val` has been received from `from`.
func (from *DchFrom) Get() (val *big.Rat, open bool) {
	from.req <- struct{}{}
	val, open = <-from.ch
	return
}

// Drop is to be called by a consumer when finished requesting.
// The request channel is closed in order to broadcast this.
//
// In order to avoid deadlock, pending sends are drained.
func (from *DchFrom) Drop() {
	close(from.req)
	go func(from *DchFrom) {
		for _ = range from.ch {
		}
	}(from)
}

// From returns the handshaking channels
// (for use in `select` statements)
// to receive values:
//  `req` to send a request `req <- struct{}{}` and
//  `rcv` to reveive such requested value from.
func (from *DchFrom) From() (req chan<- struct{}, rcv <-chan *big.Rat) {
	return from.req, from.ch
}

// ---------------------------------------------------------------------------

// GetNextFrom `from` for `into` and report success.
// Follow it with `into.Send( f(val) )`, if ok.
func (into *DchInto) GetNextFrom(from *DchFrom) (val *big.Rat, ok bool) {
	if ok = into.Next(); ok {
		val, ok = from.Get()
	}
	if !ok {
		from.Drop()
		into.Close()
	}
	return
}

// Next is the request method.
// It returns when a request was received
// and reports whether the request channel was open.
//
// Next blocks until a requested is received.
//
// A sucessful Next is to be followed by one Send(v).
func (into *DchInto) Next() bool {
	_, ok := <-into.req
	return ok
}

// Send is to be used after a successful Next()
func (into *DchInto) Send(val *big.Rat) {
	into.ch <- val
}

// Put is the send-upon-request method
// - aka "myAnyChan <- myAny".
//
// Put is a convenience for
//  if Next() { Send(v) }
//
// Put blocks until requested to send value `val` into `into`.
func (into *DchInto) Put(val *big.Rat) bool {
	_, ok := <-into.req
	if ok {
		into.ch <- val
	}
	return ok
}

// Into returns the handshaking channels
// (for use in `select` statements)
// to send values:
//  `req` to receive a request `<-req` and
//  `snd` to send such requested value into.
func (into *DchInto) Into() (req <-chan struct{}, snd chan<- *big.Rat) {
	return into.req, into.ch
}

// Close is to be called by a producer when finished sending.
// The value channel is closed in order to broadcast this.
//
// In order to avoid deadlock, pending requests are drained.
func (into *DchInto) Close() {
	close(into.ch)
	go func(into *DchInto) {
		for _ = range into.req {
		}
	}(into)
}

// ---------------------------------------------------------------------------

// MyDchFrom returns itself.
func (c *DchFrom) MyDchFrom() *DchFrom {
	return c
}

// Cap reports the capacity of the underlying value channel.
func (c *DchFrom) Cap() int {
	return cap(c.ch)
}

// Len reports the length of the underlying value channel.
func (c *DchFrom) Len() int {
	return len(c.ch)
}

// ---------------------------------------------------------------------------

// MyDchInto returns itself.
func (c *DchInto) MyDchInto() *DchInto {
	return c
}

// Cap reports the capacity of the underlying value channel.
func (c *DchInto) Cap() int {
	return cap(c.ch)
}

// Len reports the length of the underlying value channel.
func (c *DchInto) Len() int {
	return len(c.ch)
}

// End of demand channel object
// ===========================================================================
