// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

// ===========================================================================

// GetWith returns each first value received from the two given power series
// together with their respective ok boolean.
func (U PS) GetWith(V PS) (cU *Coefficient, okU bool, cV *Coefficient, okV bool) {

	reqU, sndU := U.From()
	reqV, sndV := V.From()
	datU, datV := sndU, sndV

	datU, datV = nil, nil

	var valU, valV Coefficient

	for i := 2 * 2; i > 0; i-- {

		select {

		case reqU <- struct{}{}:
			datU, reqU = sndU, nil
		case reqV <- struct{}{}:
			datV, reqV = sndV, nil

		case valU, okU = <-datU:
			datU = nil
		case valV, okV = <-datV:
			datV = nil

		}
	}

	if okU {
		cU = &valU
	} else {
		cU = aZero
	}
	if okV {
		cV = &valV
	} else {
		cV = aZero
	}

	return
}

// getValS returns a slice with each first value received from the given power series.
//
// BUG: As of now, it works for pairs only!
func getValS(in ...PS) ([]Coefficient, []bool) {
	n := len(in)
	if n != 2 {
		panic("getValS must have exactly 2 arguments")
	}

	req := make([]chan<- struct{}, 0, n)    // we request here - initially
	snd := make([]<-chan Coefficient, 0, n) // we might receive here
	dat := make([]<-chan Coefficient, 0, n) // we shall receive here
	oks := make([]bool, 0, n)               // did we receive here?
	out := make([]Coefficient, 0, n)        // the values to be returned

	for i := 0; i < n; i++ {
		req[i], snd[i] = in[i].From()  // from
		dat[i] = nil                   // block receive on dat initially
		out[i] = *NewCoefficient(0, 0) // init
	}

	for n = 2 * n; n > 0; n-- {

		select {

		// whish we could repeat this n times
		case req[0] <- struct{}{}:
			dat[0], req[0] = snd[0], nil // open dat & block req
		case req[1] <- struct{}{}:
			dat[1], req[1] = snd[1], nil // open dat & block req

		// whish we could repeat this n times
		case out[0], oks[0] = <-dat[0]:
			dat[0] = nil // block receive on dat again
		case out[1], oks[1] = <-dat[1]:
			dat[1] = nil // block receive on dat again

		}
	}
	return out, oks
}

// ===========================================================================
