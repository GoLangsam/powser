// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

// ===========================================================================

// pairPS represents a pair of power series.
type pairPS [2]PS

// pair returns an empty pair of new power series.
func (U PS) pair() pairPS {
	return pairPS{New(), New()}
}

// Split returns a pair of power series identical to (the current remainder of) a given power series.
func (U PS) Split() [2]PS {
	UU := U.pair()
	UU.Split(U)
	return UU
}

// Split `inp` into a given pair of power series.
func (out pairPS) Split(inp PS) {
	release := make(chan struct{})
	go split(out[0], out[1], inp, release)
	close(release)
}

// ===========================================================================

// split reads a single demand channel and replicates its
// output onto two, which may be read at different rates.
//
// A process is created at first demand and dies
// after the data has been sent to both outputs.
//
// When multiple generations of split exist,
// the newest will service requests on one channel,
// (which is always renamed to be `out1`);
// the elder will service requests on the other channel, (`out2`).
//
// All generations but the newest hold queued data
// that has already been sent to `out1`.
//
// When data has finally been sent to `out2` by the newest generation,
// a signal on the release-wait channel tells the next newer
// generation to begin servicing `out2`.
//
// When `inp` becomes closed or `out1` ceases to request,
// `out1` will be closed, and -after the queue has emptied-
// the last living process will append `inp` to `out2`.
func split(out1, out2, inp PS, wait <-chan struct{}) {

	req1, _ := out1.Into()
	req2, _ := out2.Into()

	both := false // do not service both channels before <-wait
	req := false  // got valid request?

	select {
	case _, req = <-req1:

	case <-wait:
		both = true
		select {
		case _, req = <-req1:

		case _, req = <-req2: // swap
			out1, out2 = out2, out1
			// req1, req2 = req2, req1
		}
	}

	dat, ok := inp.Get()

	release := make(chan struct{})
	if ok && req { // dispatch - as we have data
		go split(out1, out2, inp, release)
		out1.Send(dat)
	} else {
		out1.Close()
	}

	if !both {
		<-wait
	}

	if ok {
		out2.Put(dat)
	}
	if !(ok && req) { // no dispatch - we're last man standing
		out2.Append(inp)
	}

	close(release)
}

// ===========================================================================
