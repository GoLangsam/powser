// Copyright 2017 Andreas Pannewitz. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ps

import (
	"math/big"

	// "github.com/GoLangsam/ps/big"
	// "github.com/GoLangsam/ps/dch.rat"
	"github.com/GoLangsam/ps/dch.big"
)

// ===========================================================================

// Coefficient of a power series - a rational number.
type Coefficient = big.Rat

// NewCoefficient returns a new coefficient `a/b`.
func NewCoefficient(a, b int64) *Coefficient {
	return big.NewRat(a, b)
}

// integer represents the result of r.Nom() & r.Denum()
type integer = *big.Int

func isZero(x integer) bool {
	// return x == 0
	return x.Cmp(big.NewInt(0)) == 0
}

// PS represents a power series as a demand channel
// of it's rational coefficients.
type PS struct {
	*dch.Dch
}

// New returns a fresh power series.
func New() PS {
	return PS{dch.New()}
}

// ===========================================================================
